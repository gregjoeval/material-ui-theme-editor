self.__precacheManifest = [
  {
    "revision": "a1e4b6563bf2d7b8671e",
    "url": "/material-ui-theme-editor/static/js/runtime~main.a1e4b656.js"
  },
  {
    "revision": "d2110a2403202fbd7b7d",
    "url": "/material-ui-theme-editor/static/js/main.d2110a24.chunk.js"
  },
  {
    "revision": "9991d65ade876adce0b2",
    "url": "/material-ui-theme-editor/static/js/1.9991d65a.chunk.js"
  },
  {
    "revision": "d2110a2403202fbd7b7d",
    "url": "/material-ui-theme-editor/static/css/main.2d4eee71.chunk.css"
  },
  {
    "revision": "4fba12c0f395e7fff556a5a141357c48",
    "url": "/material-ui-theme-editor/index.html"
  }
];