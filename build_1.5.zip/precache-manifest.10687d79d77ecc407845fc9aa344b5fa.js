self.__precacheManifest = [
  {
    "revision": "a1e4b6563bf2d7b8671e",
    "url": "/material-ui-theme-editor/static/js/runtime~main.a1e4b656.js"
  },
  {
    "revision": "53da40d4e0a9dacd314c",
    "url": "/material-ui-theme-editor/static/js/main.53da40d4.chunk.js"
  },
  {
    "revision": "88fc5742745216b93011",
    "url": "/material-ui-theme-editor/static/js/1.88fc5742.chunk.js"
  },
  {
    "revision": "53da40d4e0a9dacd314c",
    "url": "/material-ui-theme-editor/static/css/main.10f9d418.chunk.css"
  },
  {
    "revision": "49c35a07c1b37e56260e31e529077af6",
    "url": "/material-ui-theme-editor/index.html"
  }
];