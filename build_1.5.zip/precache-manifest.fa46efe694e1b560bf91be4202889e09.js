self.__precacheManifest = [
  {
    "revision": "a1e4b6563bf2d7b8671e",
    "url": "/material-ui-theme-editor/static/js/runtime~main.a1e4b656.js"
  },
  {
    "revision": "b8995bd0118356e36a75",
    "url": "/material-ui-theme-editor/static/js/main.b8995bd0.chunk.js"
  },
  {
    "revision": "88fc5742745216b93011",
    "url": "/material-ui-theme-editor/static/js/1.88fc5742.chunk.js"
  },
  {
    "revision": "b8995bd0118356e36a75",
    "url": "/material-ui-theme-editor/static/css/main.10f9d418.chunk.css"
  },
  {
    "revision": "155c6dadc09215be97d0e53d943fb6c2",
    "url": "/material-ui-theme-editor/index.html"
  }
];