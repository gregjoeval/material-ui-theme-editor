self.__precacheManifest = [
  {
    "revision": "a1e4b6563bf2d7b8671e",
    "url": "/material-ui-theme-editor/static/js/runtime~main.a1e4b656.js"
  },
  {
    "revision": "345def39bae21711f3f7",
    "url": "/material-ui-theme-editor/static/js/main.345def39.chunk.js"
  },
  {
    "revision": "fb4769e004d46263e906",
    "url": "/material-ui-theme-editor/static/js/1.fb4769e0.chunk.js"
  },
  {
    "revision": "345def39bae21711f3f7",
    "url": "/material-ui-theme-editor/static/css/main.a8bbd325.chunk.css"
  },
  {
    "revision": "d7d0638cd7a9e6dfd0bd0517bf05c7d6",
    "url": "/material-ui-theme-editor/index.html"
  }
];